import { world, system, Player } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"

world.afterEvents.itemUse.subscribe((event) => {
    const { source, itemStack } = event
    switch (itemStack.typeId) {
        case "race:music_player":
            music_player.show(source).then(r => {
                switch (r.selection) {
                    case 0:
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_saccharine,location=slot.weapon.offhand}] run playsound mp.saccharine @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_saccharine,location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dSaccharine in 19edo§r\nby: §3Deister Orchestra"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_ward, location=slot.weapon.offhand}] run playsound mp.ward @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_ward, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dWard§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_wait, location=slot.weapon.offhand}] run playsound mp.wait @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_wait, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dWait§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_strad, location=slot.weapon.offhand}] run playsound mp.strad @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_strad, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dStrad§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_stal, location=slot.weapon.offhand}] run playsound mp.stal @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_stal, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dStal§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_relic, location=slot.weapon.offhand}] run playsound mp.relic @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_relic, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dRelic§r\nby: §3Aaron Cherof"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_precipice, location=slot.weapon.offhand}] run playsound mp.precipice @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_precipice, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dPrecipice§r\nby: §3Aaron Cherof"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_pigstep, location=slot.weapon.offhand}] run playsound mp.pigstep @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_pigstep, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dPigstep§r\nby: §3Lena Raine"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_otherside, location=slot.weapon.offhand}] run playsound mp.otherside @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_otherside, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dOtherside§r\nby: §3Lena Raine"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_mellohi, location=slot.weapon.offhand}] run playsound mp.mellohi @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_mellohi, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dMellohi§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_mall, location=slot.weapon.offhand}] run playsound mp.mall @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_mall, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dMall§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_far, location=slot.weapon.offhand}] run playsound mp.far @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_far, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dFar§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_creator_mb, location=slot.weapon.offhand}] run playsound mp.creator_mb @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_creator_mb, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dCreator ( Music Box Version )§r\nby: §3Lena Raine"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_creator, location=slot.weapon.offhand}] run playsound mp.creator @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_creator, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dCreator§r\nby: §3Lena Raine"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_chirp, location=slot.weapon.offhand}] run playsound mp.chirp @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_chirp, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dChirp§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_cat, location=slot.weapon.offhand}] run playsound mp.cat @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_cat, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dCat§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_blocks, location=slot.weapon.offhand}] run playsound mp.blocks @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_blocks, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§dBlocks§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_5, location=slot.weapon.offhand}] run playsound mp.5 @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_5, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§d5§r\nby: §3Samuel Aberg"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_11, location=slot.weapon.offhand}] run playsound mp.11 @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_11, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§d11§r\nby: §3C418"}]}');

                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_13, location=slot.weapon.offhand}] run playsound mp.13 @a[r=10] ~ ~ ~');
                        event.source.runCommandAsync('execute at @s[hasitem={item=race:mp_13, location=slot.weapon.offhand}] run tellraw @s {"rawtext":[{"text":"§6§l[ Music Player ]§r§a Now Playing§r:\n\n§d13§r\nby: §3C418"}]}');

                        break;

                    case 1:
                        event.source.runCommand('stopsound @s');
                        break;

                    case 2:
                        mp_guide.show(source);
                        break;

                    default:
                        break;
                }
            })
    }
})

world.afterEvents.itemUse.subscribe((event) => {
    const { source, itemStack } = event
    switch (itemStack.typeId) {
        case "race:race_orb":
            racemenu.show(source).then(r => {
                switch (r.selection) {
                    case 0:
                        racemenu_human.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.runCommand('tellraw @s[tag=race_human] {"rawtext":[{"text":"Race Change Unsuccesful.\n\nYOU ALREADY HAVE THIS RACE!"}]}')
                                    event.source.runCommand('title @s[tag=!race_human] title Race Selected!');
                                    event.source.runCommand('tellraw @s[tag=!race_human] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e Your Race Will Change in:"}]}');
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=!race_human] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 3"}]}'), 20);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=!race_human] ~ ~ ~ 1 1.5 1'), 20);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=!race_human] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 2"}]}'), 40);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=!race_human] ~ ~ ~ 1 1.5 1'), 40);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=!race_human] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 1"}]}'), 60);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=!race_human] ~ ~ ~ 1 1.5 1'), 60);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove race_elven'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove race_dwarf'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove race_avian'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove nightvision_off'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove nightvision_on'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=!race_human] remove has_wings'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:elven_ears'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:elven_superjump'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:elf_nightvission_off'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:elf_nightvission_on'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:dwarf_haste'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:dwarfs_fury'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] race:super_launch'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=!race_human] firework_rocket'), 85);
                                    system.runTimeout(() => event.source.runCommand('execute if entity @s[tag=!race_human] run tellraw @a {"rawtext":[{"text":"§e§l"},{"selector":"@s"},{"text":"§r changed his/her race to human!"}]}'), 80);
                                    system.runTimeout(() => event.source.addTag('race_human'), 85);
                                    system.runTimeout(() => event.source.removeTag('race_feline'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:feline_helmet'), 84);
                                    system.runTimeout(() => event.source.addTag('is_changing'), 20);
                                    system.runTimeout(() => event.source.removeTag('is_changing'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('particle race:race_change ~ ~ ~'), 80);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_human] race:feline_charge'), 86);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_human] race:feline_super_jump'), 86);
                                    event.source.runCommand('clear @s race:race_orb 0 1');


                                    break;
                            }
                        })
                        break;

                    case 1:
                        racemenu_elf.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.addTag('race_elven');
                                    event.source.runCommand('title @s[tag=race_elven] title Race Selected!');
                                    event.source.runCommand('tellraw @s[tag=race_elven] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e Your Race Will Change in:"}]}');
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_elven] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 3"}]}'), 20);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_elven] ~ ~ ~ 1 1.5 1'), 20);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_elven] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 2"}]}'), 40);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_elven] ~ ~ ~ 1 1.5 1'), 40);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_elven] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 1"}]}'), 60);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_elven] ~ ~ ~ 1 1.5 1'), 60);
                                    system.runTimeout(() => event.source.addTag('nightvision_off'), 85);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @a[tag=race_elven] slot.armor.head 0 race:elven_ears 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 85);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @a[tag=race_elven] slot.hotbar 7 race:elf_nightvission_off 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 85);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @a[tag=race_elven] slot.hotbar 8 race:elven_superjump 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 85);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_elven] remove race_human'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_elven] remove race_dwarf'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_elven] remove race_avian'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_elven] remove has_wings'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:dwarf_haste'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:dwarfs_fury'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:super_launch'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s firework_rocket'), 84);
                                    system.runTimeout(() => event.source.runCommand('tellraw @a {"rawtext":[{"text":"§e§l"},{"selector":"@s"},{"text":"§r changed his/her race to an Elf!"}]}'), 85);
                                    system.runTimeout(() => event.source.removeTag('race_feline'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:feline_helmet'), 84);
                                    system.runTimeout(() => event.source.addTag('is_changing'), 20);
                                    system.runTimeout(() => event.source.removeTag('is_changing'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('particle race:race_change ~ ~ ~'), 80);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_elven] race:feline_charge'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_elven] race:feline_super_jump'), 84);
                                    event.source.runCommand('clear @s race:race_orb 0 1');




                                    break;
                            }
                        })
                        break;

                    case 2:
                        racemenu_avian.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.addTag('race_avian');
                                    event.source.runCommand('title @s[tag=race_avian] title Race Selected!');
                                    event.source.runCommand('tellraw @s[tag=race_avian] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e Your Race Will Change in:"}]}');
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_avian] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 3"}]}'), 20);
                                    system.runTimeout(() => event.source.addTag('is_changing'), 20);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_avian] ~ ~ ~ 1 1.5 1'), 20);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_avian] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 2"}]}'), 40);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_avian] ~ ~ ~ 1 1.5 1'), 40);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_avian] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 1"}]}'), 60);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_avian] ~ ~ ~ 1 1.5 1'), 60);
                                    system.runTimeout(() => event.source.runCommand('execute if entity @a[tag=race_avian] run replaceitem entity @a[tag=race_avian] slot.hotbar 7 race:super_launch 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 84)
                                    system.runTimeout(() => event.source.addTag('has_wings'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_avian] remove race_human'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_avian] remove race_elven'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_avian] remove race_dwarf'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_avian] remove nightvision_off'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s[tag=race_avian] remove nightvision_on'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_avian] race:elven_ears'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_avian] race:dwarf_haste'), 84);
                                    system.runTimeout(() => event.source.removeTag('race_feline'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:feline_helmet'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_avian] race:dwarfs_fury'), 84);
                                    system.runTimeout(() => event.source.removeTag('is_changing'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('particle race:race_change ~ ~ ~'), 80);
                                    system.runTimeout(() => event.source.runCommand('tellraw @a {"rawtext":[{"text":"§e§l"},{"selector":"@s"},{"text":"§r changed his/her race to an Avian!"}]}'), 85);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_avian] race:feline_charge'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_avian] race:feline_super_jump'), 84);
                                    event.source.runCommand('clear @s race:race_orb 0 1');



                                    break;
                            }
                        })
                        break;

                    case 3:
                        racemenu_dwarf.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.addTag('race_dwarf');
                                    event.source.runCommand('title @s[tag=race_dwarf] title Race Selected!');
                                    event.source.runCommand('tellraw @s[tag=race_dwarf] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e Your Race Will Be Changed in:"}]}');
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_dwarf] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 3"}]}'), 20);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_dwarf] ~ ~ ~ 1 1.5 1'), 20);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_dwarf] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 2"}]}'), 40);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_dwarf] ~ ~ ~ 1 1.5 1'), 40);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_dwarf] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 1"}]}'), 60);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_dwarf] ~ ~ ~ 1 1.5 1'), 60);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_human'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_elven'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_avian'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove nightvision_off'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove nightvision_on'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove has_wings'), 84);
                                    system.runTimeout(() => event.source.removeTag('race_feline'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:feline_helmet'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s race:elven_ears'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:elven_superjump'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:feline_charge'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:feline_super_jump'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:elf_nightvission_off'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:elf_nightvission_on'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] race:super_launch'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_dwarf] firework_rocket'), 84);
                                    system.runTimeout(() => event.source.runCommand('tellraw @a {"rawtext":[{"text":"§e§l"},{"selector":"@s"},{"text":"§r changed his/her race to Dwarf!"}]}'), 85);
                                    system.runTimeout(() => event.source.addTag('is_changing'), 20);
                                    system.runTimeout(() => event.source.removeTag('is_changing'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('particle race:race_change ~ ~ ~'), 80);
                                    system.runTimeout(() => event.source.runCommandAsync('replaceitem entity @a[tag=race_dwarf] slot.hotbar 8 race:dwarf_haste 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('replaceitem entity @a[tag=race_dwarf] slot.hotbar 7 race:dwarfs_fury 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 84);
                                    event.source.runCommand('clear @s race:race_orb 0 1');

                                    break;

                            }
                        })
                        break;

                    case 4:
                        racemenu_feline.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.addTag('race_feline');
                                    event.source.runCommand('title @s[tag=race_feline] title Race Selected!');
                                    event.source.runCommand('tellraw @s[tag=race_feline] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e Your Race Will Be Changed in:"}]}');
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_feline] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 3"}]}'), 20);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_feline] ~ ~ ~ 1 1.5 1'), 20);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_feline] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 2"}]}'), 40);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_feline] ~ ~ ~ 1 1.5 1'), 40);
                                    system.runTimeout(() => event.source.runCommand('tellraw @s[tag=race_feline] {"rawtext":[{"text":"§4§l[ Race ]"},{"text":"§r§e 1"}]}'), 60);
                                    system.runTimeout(() => event.source.runCommand('playsound random.levelup @s[tag=race_feline] ~ ~ ~ 1 1.5 1'), 60);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_human'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_elven'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_avian'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove race_dwarf'), 84)
                                    system.runTimeout(() => event.source.runCommand('tag @s remove nightvision_off'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove nightvision_on'), 84);
                                    system.runTimeout(() => event.source.runCommand('tag @s remove has_wings'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:elven_ears'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:elven_superjump'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:elf_nightvission_off'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:elf_nightvission_on'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:super_launch'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:dwarfs_fury'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] race:dwarf_haste'), 84);
                                    system.runTimeout(() => event.source.runCommand('clear @s[tag=race_feline] firework_rocket'), 84);
                                    system.runTimeout(() => event.source.runCommand('tellraw @a {"rawtext":[{"text":"§e§l"},{"selector":"@s"},{"text":"§r changed his/her race to Feline!"}]}'), 85);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @a[tag=race_feline] slot.armor.head 0 race:feline_helmet 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 85);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @s slot.hotbar 8 race:feline_charge 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 84);
                                    system.runTimeout(() => event.source.runCommand('replaceitem entity @s slot.hotbar 7 race:feline_super_jump 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'), 84);
                                    system.runTimeout(() => event.source.addTag('is_changing'), 20);
                                    system.runTimeout(() => event.source.removeTag('is_changing'), 84);
                                    system.runTimeout(() => event.source.runCommandAsync('particle race:race_change ~ ~ ~'), 80);
                                    event.source.runCommand('clear @s race:race_orb 0 1');

                                    break;
                            }
                        })
                        break;
                }
            })
            break;

    };
});

world.afterEvents.itemUse.subscribe((event) => {
    const { source, itemStack } = event
    switch (itemStack.typeId) {
        case "race:main_menu":
            mainmenu.show(source).then(r => {
                switch (r.selection) {

                    case 0:
                        info.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    info_server.show(source);
                                    break;

                                case 1:
                                    info_addon.show(source);
                                    break;
                            }
                        })
                        break;

                    case 1:
                        sizemenu.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    system.runTimeout(() => event.source.runCommand('playanimation @a animation.playersize.tall none 0 "0" a'), 5);
                                    event.source.runCommand('playanimation @a animation.playersize.short none 0 "1" a');
                                    event.source.runCommand('tellraw @s {"rawtext":[{"text":"§2§l[ Size Menu ]§r Tall Player Size Chosen. Change your perspective to third person to show the results :)"}]}');
                                    break;

                                case 1:
                                    event.source.runCommand('playanimation @a animation.playersize.tall none 0 "1" a');
                                    event.source.runCommand('playanimation @a animation.playersize.short none 0 "1" a');
                                    event.source.runCommand('tellraw @s {"rawtext":[{"text":"§2§l[ Size Menu ]§r Your size has been reset"}]}');
                                    break;

                                case 2:
                                    system.runTimeout(() => event.source.runCommand('playanimation @s animation.playersize.short none 0 "0" a'), 5);
                                    event.source.runCommand('playanimation @a animation.playersize.tall none 0 "1" a');
                                    event.source.runCommand('tellraw @s {"rawtext":[{"text":"§2§l[ Size Menu ]§r Short Player Size Chosen. Change your perspective to third person to show the results :)"}]}');
                                    break;
                            }
                        })
                        break;

                    case 2:
                        toogle_abbilities.show(source).then(r => {
                            switch (r.selection) {
                                case 0:
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:feline_charge, location=slot.hotbar, slot=8, quantity=0},tag=race_feline] run replaceitem entity @s slot.hotbar 8 race:feline_charge 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:super_launch, location=slot.hotbar, slot=8, quantity=0},tag=race_avian] run replaceitem entity @s slot.hotbar 7 race:super_launch 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elf_nightvission_on, location=slot.hotbar, slot=7, quantity=0},tag=nightvision_on] run replaceitem entity @s slot.hotbar 7 race:elf_nightvission_on 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elf_nightvission_off, location=slot.hotbar, slot=7, quantity=0},tag=nightvision_off] run replaceitem entity @s slot.hotbar 7 race:elf_nightvission_off 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elven_superjump, location=slot.hotbar, slot=8, quantity=0},tag=race_elven] run replaceitem entity @s slot.hotbar 8 race:elven_superjump 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:feline_super_jump, location=slot.hotbar, slot=7, quantity=0},tag=race_feline] run replaceitem entity @s slot.hotbar 7 race:feline_super_jump 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[tag=race_dwarf,hasitem={item=race:dwarfs_fury, location=slot.hotbar, slot=7, quantity=0}] run replaceitem entity @s slot.hotbar 7 race:dwarfs_fury 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');
                                    event.source.runCommand('execute if entity @s[tag=race_dwarf, hasitem={item=race:dwarf_haste, location=slot.hotbar, slot=8, quantity=0}] run replaceitem entity @s slot.hotbar 8 race:dwarf_haste 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}');


                                    break;
                                case 1:
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:super_launch, location=slot.hotbar, slot=8, quantity=1},tag=race_avian] run replaceitem entity @s slot.hotbar 7 air');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elf_nightvission_on, location=slot.hotbar, slot=7, quantity=1},tag=race_elven] run replaceitem entity @s slot.hotbar 7 air');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elf_nightvission_off, location=slot.hotbar, slot=7, quantity=1},tag=race_elven] run replaceitem entity @s slot.hotbar 7 air');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:elven_superjump, location=slot.hotbar, slot=8, quantity=1},tag=race_elven] run replaceitem entity @s slot.hotbar 8 air');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:feline_super_jump, location=slot.hotbar, slot=7, quantity=1},tag=race_feline] run replaceitem entity @s slot.hotbar 7 air');
                                    event.source.runCommand('execute if entity @s[hasitem={item=race:feline_charge, location=slot.hotbar, slot=8, quantity=1},tag=race_feline] run replaceitem entity @s slot.hotbar 8 air');
                                    event.source.runCommand('execute if entity @s[tag=race_dwarf,hasitem={item=race:dwarfs_fury, location=slot.hotbar, slot=7, quantity=1}] run replaceitem entity @s slot.hotbar 7 air');
                                    event.source.runCommand('execute if entity @s[tag=race_dwarf, hasitem={item=race:dwarf_haste, location=slot.hotbar, slot=8, quantity=1}] run replaceitem entity @s slot.hotbar 8 air');

                                    break;
                            }
                        })
                        break;
                    case 3:
                        credits.show(source);
                        break;

                    default:
                        break;

                };
            })
    }
});

const racemenu = new ActionFormData()
    .title("Race Menu")
    .body('Change your race with just one click of a button!')
    //0
    .button('')
    //1
    .button('')
    //2
    .button('')
    //3
    .button('')
    //4
    .button(' ( NEW )')

const racemenu_human = new ActionFormData()
    .title('')
    .body("")
    .button('Choose')

const racemenu_elf = new ActionFormData()
    .title('')
    .body('')
    .button('Choose')

const racemenu_avian = new ActionFormData()
    .title('')
    .body('')
    .button('Choose')

const racemenu_dwarf = new ActionFormData()
    .title('')
    .body('')
    .button('Choose')

const racemenu_feline = new ActionFormData()
    .title('')
    .body('')
    .button('Choose')

const mainmenu = new ActionFormData()
    .title("")
    .body("\n\n")
    //0
    .button("§5Info", "textures/ui/info")
    //1
    .button("§5Player Size ( BETA )", "textures/ui/playersizemenu")
    //2
    .button('§5Toggle Abbilities ( BETA )', "textures/ui/racemenu")
    //3
    .button("§5Credits", "textures/ui/credits")

const info = new ActionFormData()
    .title("Addon Info")
    .body("Info About Endfallen's Races")
    //0
    .button("About")
    //1
    .button('Version Info')

const info_server = new ActionFormData()
    .title('About')
    .body("Endfallen's Races is an addon that was made for one realm called 'EndfallenSMP'.\n\nThis one realm has motivated me to begin making addons for Minecraft: Bedrock Edition. But i don't think that i will stay as only an Addon Creator. I might also start making some mods. All because of those tiny gremlins in my SMP... Love ya Gremlins, Have fun <3")
    .button('Exit')

const info_addon = new ActionFormData()
    .title('Version Info')
    .body("§5§lEndfallen's Races§r\n\nVersion: v1.0.1\n\nBeta?: No\n\nChanges:\n\n- Fixed Feline Ears;\n-Fixed Feline's Jump\n- Debuffed Feline's Fury\n\nMain Developer: SamuraiBread\n\nVersion Testers:\n-Olix00\n- wisnia\n- Karton04")
    .button('Exit')


const sizemenu = new ActionFormData()
    .title("Size Menu")
    .body("Be Aware!\n\nIf you die, you will need to choose the size once again. And if you choose your size, you will need to relog to change it once again!\n\nEnjoy being short ;)")
    .button("Tall")
    .button("Normal")
    .button("Short")

const toogle_abbilities = new ActionFormData()
    .title("Toogle Abbilities")
    .body('Toggle your abbilities with this menu.')
    .button('Enable Abbilities')
    .button('Disable Abbilities')

const music_player = new ActionFormData()
    .title('')
    .body('Put the disc in the offhand and hit play to play a music disk.\n\n§4Works only for Music Player discs! Hit Guide button to get more info.')
    .button('§2§lPlay §3( Offhand )', "textures/ui/ui_mp_play")
    .button('§4§lStop', 'textures/ui/ui_mp_stop')
    .button('§6§lGuide', 'textures/ui/ui_mp_guide')

const mp_guide = new ActionFormData()
    .title('Music Player Guide')
    .body('§3How Does the §6§l[Music Player]§r§3 Work?§r\nIt’s really §asimple§r! Here’s how you can use it.\n\n§b§lConverting Vanilla Music Discs§r\n\nTo play a standard Minecraft Music Disc in the ERA Music Player, you first need to §econvert it into ERA’s special version§r.\nDon’t worry, it’s an §beasy§r process.\n\nFirst, open your §ainventory§r crafting grid.\n\nThen, place a §evanilla Music Disc§r in any crafting slot.\n\nThis will transform it into the §dERA Music Disc version§r.\n\nOnce you have the §dERA version§r of the disc, put it in your §a§loff-hand§r slot and use the §6§lMusic Player item§r.\nThe Music Player is now ready to go.\n\n§c§lERA-Exclusive Music Discs§r\n\nIf you`re using new music discs added by ERA, you don`t need to convert them.\n\nSimply place the disc in your §aoff-hand§r and use the §6Music Player item§r to start playing music.\n\n\n§e§lNow you`re all set to experience ERA`s music system in the best way possible.')
    .button('I understand now')

//Elves' Super Jump
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:jump', {
        onUse(event) {
            event.source.runCommand("effect @s levitation 1 25 true"),
                event.source.runCommand("playsound mob.enderdragon.flap @a ~ ~ ~ 1 2 1"),
                event.source.runCommand("particle race:superjump2 ~ ~ ~"),
                event.source.runCommand("particle race:superjump1 ~ ~ ~"),
                system.runTimeout(() => event.source.runCommand("effect @s slow_falling 5 1 true"), 40);
            system.runTimeout(() => event.source.runCommand('playsound script.magic.ping @s'), 600);
            system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lSuper Jump"},{"text":"§r§2 Ready!"}]}'), 600);
        }
    });
});

//Dwarf's Super Haste
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:superhaste', {
        onUse(event) {
            event.source.runCommand("effect @s haste 10 3 true"),
                event.source.runCommand("title @s title Haste Activated"),
                system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lSuper Haste"},{"text":"§r§2 Ready!"}]}'), 1200);
            system.runTimeout(() => event.source.runCommand('playsound script.magic.ping @s'), 1200);
        }
    });
});

//Elven's Nighvission ON - Use component on nightvission off
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:nightvision_enable', {
        onUse(event) {
            event.source.runCommand("tag @s add nightvision_on"),
                event.source.runCommand('execute if entity @a[tag=nightvision_on] run replaceitem entity @a[tag=nightvision_on] slot.hotbar 7 race:elf_nightvission_on 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'),
                event.source.runCommand("tag @s remove nightvision_off"),
                event.source.runCommand("playsound beacon.activate @s ~ ~ ~ 1 1 1"),
                system.runTimeout(() => event.source.runCommand("playsound script.magic.ping @s"), 1200);
            system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lNight Vision"},{"text":"§r§2 Can Be Disabled!"}]}'), 1200);

        }
    });
});

//Elven NV Off
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:nightvision_disabled', {
        onUse(event) {
            event.source.runCommand("tag @s add nightvision_off"),
                event.source.runCommand('execute if entity @a[tag=nightvision_off] run replaceitem entity @a[tag=nightvision_off] slot.hotbar 7 race:elf_nightvission_off 1 0 {"minecraft:keep_on_death":{},"minecraft:item_lock":{"mode":"lock_in_slot"}}'),
                event.source.runCommand("tag @s remove nightvision_on"),
                event.source.runCommand("playsound beacon.deactivate @s ~ ~ ~ 1 1 1"),
                event.source.runCommand('effect @s night_vision 0')
            system.runTimeout(() => event.source.runCommand("playsound script.magic.ping @s"), 2400);
            system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lNight Vision"},{"text":"§r§2 Can Be Enabled!"}]}'), 2400);
        }
    });
});


//Cancel Block

world.beforeEvents.worldInitialize.subscribe((event) => {
    event.blockComponentRegistry.registerCustomComponent('race:cancel_block', {
        onPlayerInteract(event) {

        }
    });
});


//Dwarf's Fury
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:dwarffury', {
        onUse(event) {
            event.source.runCommand('effect @s strength 30 2 true'),
                event.source.runCommand('effect @s resistance 30 2 true'),
                event.source.runCommand('title @s title §4Fury Activated'),
                event.source.runCommand('playsound mob.endermen.scream @s ~ ~ ~ 1 0.3 1'),
                event.source.runCommand('playsound random.totem @s ~ ~ ~ 1 0.3 1'),
                system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lDwarfs Furry,{"text":"§r§2 Ready!"}]}'), 2400);
        }
    });
});

//Avian Launch 
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:avianlaunch', {
        onUse(event) {
            event.source.addTag('launch'),
                system.runTimeout(() => event.source.removeTag('launch'), 60);
        }
    })
});


//Tea
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:tea', {
        onCompleteUse(event) {
            event.source.runCommand('effect @s regeneration 10 3 true'),
                event.source.runCommand('effect @s speed 10 2 true')
        }
    });
});


//Permadeath Sword
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent("race:permadeath", {
        onCompleteUse(event) {
            event.source.runCommand('execute at @a[tag=can_die,r=50] run summon lightning_bolt ~ ~ ~ '),
                event.source.runCommand('tag @a[tag=can_die,r=50] add dead'),
                event.source.runCommand('tag @a[tag=dead,r=50] remove can_die'),
                event.source.runCommand("title @a[tag=can_die,r=50] title §4You've died"),
                event.source.startItemCooldown('spirit', 600),
                event.source.runCommand('playsound cs.q1finale2 @a ~ ~ ~ 1 0.5 1'),
                event.source.runCommand('tellraw @a {"rawtext":[{"text":"§7Someone PermaDied..."}]}'),
                event.source.runCommand('effect @a[tag=dead] blindness infinite 25 true'),
                event.source.runCommand('camerashake add @a 0.5 10'),
                system.runTimeout(() => event.source.runCommand('playsound permadeath.final @a'), 20);
        },

        onHitEntity(event) {
            event.hitEntity.addTag('can_die'),
                event.hitEntity.runCommandAsync('title @s[tag=!can_die] title PermaDeath Warning')
            event.hitEntity.runCommandAsync('title @s[tag=!can_die] subtitle Your character can PermaDie now.')
            system.runTimeout(() => event.hitEntity.removeTag('can_die'), 6000)
        },
        onUse(event) {
            event.source.runCommandAsync('playsound permadeath.start @a ~ ~ ~ 1 1 1'),
                event.source.runCommandAsync('effect @a darkness 10 3 true')

        }

    });
});

//Founder Powers:

//The Devourer
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent("race:the_devouer", {
        onUse(event) {
            event.source.addTag('founder_charging'),
                event.source.runCommandAsync('playsound founder.power @a')
            system.runTimeout(() => event.source.removeTag('founder_charging'), 240)
            system.runTimeout(() => event.source.runCommandAsync("title @a title §4=)"), 240);
            system.runTimeout(() => event.source.runCommandAsync("execute at @e[rm=1,r=100] run summon evocation_fang ~ ~ ~ ~ ~"), 380);
            system.runTimeout(() => event.source.runCommandAsync("effect @e[rm=1,r=100] instant_damage 1 2 true"), 380);
        }
    })
})

//The Liar

world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:the_liar', {
        onUse(event) {
            event.source.addTag('is_invisible')
        },
        onCompleteUse(event) {
            event.source.removeTag('is_invisible')

        }
    })
});
//The Destroyer
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent("race:the_destroyer", {
        onUse(event) {
            event.source.runCommandAsync('playsound founder.power2 @a'),
                event.source.runCommandAsync('effect @a darkness 25 1 true'),
                system.runTimeout(() => event.source.addTag('founder_destroyer'), 270);
            system.runTimeout(() => event.source.runCommandAsync('effect @e[rm=1,r=100] wither 20 1 true'), 270);
            system.runTimeout(() => event.source.removeTag('founder_destroyer'), 630);
            system.runTimeout(() => event.source.addTag('founder_destroyer1'), 700);
            system.runTimeout(() => event.source.removeTag('founder_destroyer1'), 1100);
            system.runTimeout(() => event.source.runCommandAsync('damage @e[rm=1, r=100] 20 entity_attack'), 1100);



        }
    })
});

//Warhammer
world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:warhammer', {
        onHitEntity(event) {
            event.hitEntity.addEffect('slowness', 10, {
                amplifier: 2,
            });

        },
        onUse(event) {
            event.source.runCommandAsync('playanimation @s animation.player.warhammer.use'),
                event.source.runCommandAsync('inputpermission set @s movement disabled'),
                system.runTimeout(() => event.source.runCommandAsync("playsound warhammer.use @a"), 35);
            system.runTimeout(() => event.source.runCommandAsync("damage @e[rm=1,r=20] 15 mace_smash entity @s"), 45);
            system.runTimeout(() => event.source.runCommandAsync("particle race:warhammer_use_particles ~ ~ ~"), 45);
            system.runTimeout(() => event.source.runCommandAsync('effect @e[rm=1,r=20] levitation 1 25'), 60.5);
            system.runTimeout(() => event.source.runCommandAsync('camera @a[rm=1,r=20] fade time 0 6 3'), 60.5);
            system.runTimeout(() => event.source.runCommandAsync('inputpermission set @s movement enabled'), 60.5);
            system.runTimeout(() => event.source.runCommandAsync('playsound warhammer.knockout @a[rm=1,r=20]'), 45);
            system.runTimeout(() => event.source.runCommandAsync('effect @e[rm=1,r=80] levitation 0'), 70.5);

        }
    })
});

world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:feline_charge', {
        onUse(event) {
            event.source.runCommand('playsound warhammer.use @a ~ ~ ~ 1 0.3 1');
            event.source.runCommand('particle race:feline_charge ~ ~ ~');
            event.source.runCommand('effect @s speed 30 5 true');
            event.source.runCommand('effect @s strength 30 2 true');
            event.source.runCommand('effect @s absorption 30 3 true');
            event.source.startItemCooldown('feline_charge', 260);
            system.runTimeout(() => event.source.runCommand("playsound script.magic.ping @s"), 260);
            system.runTimeout(() => event.source.runCommand('tellraw @s {"rawtext":[{"text":"§c[Abillity] "},{"text":"§a§lFeline Charge"},{"text":"§r§2 Can Be Enabled!"}]}'), 100);

        }
    })
});

world.beforeEvents.worldInitialize.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent('race:feline_jump', {
        onUse(event) {
            event.source.addTag('launch');
            system.runTimeout(() => event.source.removeTag('launch'), 60);

        }
    });
});